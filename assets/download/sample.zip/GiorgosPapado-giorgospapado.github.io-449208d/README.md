# spatial-coco-certh
spatial dataset website
